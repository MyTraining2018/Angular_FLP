import { Component } from 'angular2/core';
import { ProductListComponent } from './products/product-list.component';

@Component({
    selector: 'cap-app',
    templateUrl:'app/app.component.html',
    directives: [ProductListComponent]

})

export class AppComponent{
    pageTitle: string= 'CAP Product Management';
}
